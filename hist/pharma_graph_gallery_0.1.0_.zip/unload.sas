filename P81B2EC0 list;

%put NOTE: Unloading package Pharma_Graph_Gallery, version 0.1.0, license MIT;
%put NOTE- *** START ***;

proc sql;
  create table WORK._%sysfunc(datetime(), hex16.)_ as
  select memname, objname, objtype
  from dictionary.catalogs
  where 
  (
   objname in ("*"
   ,'PHARMA_GRAPH_GALLERYIML'
   ,'PHARMA_GRAPH_GALLERYCASLUDF'

   %put NOTE- Element of type macro generated from the file "pharma_graph_gallery.sas" will be deleted;
   %put NOTE- ;
   ,"PHARMA_GRAPH_GALLERY                                            "

   %put NOTE- Element of type macro generated from the file "sg001.sas" will be deleted;
   %put NOTE- ;
   ,"SG001                                                           "

   %put NOTE- Element of type macro generated from the file "sg002.sas" will be deleted;
   %put NOTE- ;
   ,"SG002                                                           "

   %put NOTE- Element of type macro generated from the file "sg003.sas" will be deleted;
   %put NOTE- ;
   ,"SG003                                                           "

   %put NOTE- Element of type macro generated from the file "sg004.sas" will be deleted;
   %put NOTE- ;
   ,"SG004                                                           "

   %put NOTE- Element of type macro generated from the file "sg005.sas" will be deleted;
   %put NOTE- ;
   ,"SG005                                                           "

   %put NOTE- Element of type macro generated from the file "sg006.sas" will be deleted;
   %put NOTE- ;
   ,"SG006                                                           "

   %put NOTE- Element of type macro generated from the file "sg007.sas" will be deleted;
   %put NOTE- ;
   ,"SG007                                                           "

   %put NOTE- Element of type macro generated from the file "sg008.sas" will be deleted;
   %put NOTE- ;
   ,"SG008                                                           "

   %put NOTE- Element of type macro generated from the file "sg009.sas" will be deleted;
   %put NOTE- ;
   ,"SG009                                                           "

   %put NOTE- Element of type macro generated from the file "sg010.sas" will be deleted;
   %put NOTE- ;
   ,"SG010                                                           "

   %put NOTE- Element of type macro generated from the file "sg011.sas" will be deleted;
   %put NOTE- ;
   ,"SG011                                                           "

   %put NOTE- Element of type macro generated from the file "sg012.sas" will be deleted;
   %put NOTE- ;
   ,"SG012                                                           "

   %put NOTE- Element of type macro generated from the file "sg013.sas" will be deleted;
   %put NOTE- ;
   ,"SG013                                                           "

   %put NOTE- Element of type macro generated from the file "sg014.sas" will be deleted;
   %put NOTE- ;
   ,"SG014                                                           "

   %put NOTE- Element of type macro generated from the file "sg015.sas" will be deleted;
   %put NOTE- ;
   ,"SG015                                                           "

   %put NOTE- Element of type macro generated from the file "sg016.sas" will be deleted;
   %put NOTE- ;
   ,"SG016                                                           "

   %put NOTE- Element of type macro generated from the file "sg017.sas" will be deleted;
   %put NOTE- ;
   ,"SG017                                                           "

   %put NOTE- Element of type macro generated from the file "sg018.sas" will be deleted;
   %put NOTE- ;
   ,"SG018                                                           "

   %put NOTE- Element of type macro generated from the file "sg019.sas" will be deleted;
   %put NOTE- ;
   ,"SG019                                                           "

   %put NOTE- Element of type macro generated from the file "sg020.sas" will be deleted;
   %put NOTE- ;
   ,"SG020                                                           "

   %put NOTE- Element of type macro generated from the file "sg022.sas" will be deleted;
   %put NOTE- ;
   ,"SG022                                                           "

   %put NOTE- Element of type macro generated from the file "sg023.sas" will be deleted;
   %put NOTE- ;
   ,"SG023                                                           "

   %put NOTE- Element of type macro generated from the file "sg024.sas" will be deleted;
   %put NOTE- ;
   ,"SG024                                                           "

   %put NOTE- Element of type macro generated from the file "sg025.sas" will be deleted;
   %put NOTE- ;
   ,"SG025                                                           "

   %put NOTE- Element of type macro generated from the file "sg026.sas" will be deleted;
   %put NOTE- ;
   ,"SG026                                                           "

   %put NOTE- Element of type macro generated from the file "sg027.sas" will be deleted;
   %put NOTE- ;
   ,"SG027                                                           "

   %put NOTE- Element of type macro generated from the file "sg028.sas" will be deleted;
   %put NOTE- ;
   ,"SG028                                                           "

   %put NOTE- Element of type macro generated from the file "sg029.sas" will be deleted;
   %put NOTE- ;
   ,"SG029                                                           "

   %put NOTE- Element of type macro generated from the file "sg030.sas" will be deleted;
   %put NOTE- ;
   ,"SG030                                                           "

   %put NOTE- Element of type macro generated from the file "sg033.sas" will be deleted;
   %put NOTE- ;
   ,"SG033                                                           "

   %put NOTE- Element of type macro generated from the file "sg034.sas" will be deleted;
   %put NOTE- ;
   ,"SG034                                                           "

   %put NOTE- Element of type macro generated from the file "sg035.sas" will be deleted;
   %put NOTE- ;
   ,"SG035                                                           "

   %put NOTE- Element of type macro generated from the file "sg036.sas" will be deleted;
   %put NOTE- ;
   ,"SG036                                                           "

   %put NOTE- Element of type macro generated from the file "sg037.sas" will be deleted;
   %put NOTE- ;
   ,"SG037                                                           "

   %put NOTE- Element of type macro generated from the file "sg038.sas" will be deleted;
   %put NOTE- ;
   ,"SG038                                                           "

   %put NOTE- Element of type macro generated from the file "sg039.sas" will be deleted;
   %put NOTE- ;
   ,"SG039                                                           "

   %put NOTE- Element of type macro generated from the file "sg040.sas" will be deleted;
   %put NOTE- ;
   ,"SG040                                                           "

   %put NOTE- Element of type macro generated from the file "z_dummy_swimmer.sas" will be deleted;
   %put NOTE- ;
   ,"Z_DUMMY_SWIMMER                                                 "

  )
  and objtype = "MACRO"
  and libname  = "WORK"
  )
  or
  (
   objname in ("*"

  )
  and objtype in ("FORMAT" "FORMATC" "INFMT" "INFMTC")
  and libname  = "WORK"
  and memname = 'PHARMA_GRAPH_GALLERYFORMAT'
  )
  order by objtype, memname, objname
  ;
quit;
data _null_;
  do until(last.memname);
    set WORK._last_;
    by objtype memname;
    if first.memname then call execute("proc catalog cat = work." !! strip(memname) !! " force;");
    call execute("delete " !! strip(objname) !! " /  et =" !! objtype !! "; run;");
  end;
  call execute("quit;");
run;
proc delete data = WORK._last_;
run;
proc fcmp outlib = work.Pharma_Graph_Galleryfcmp.package;
run;

proc SQL noprint;
quit;

data _null_; call symputx("_DS2_2_del_",0,"L"); run;
proc SQL noprint;
quit;

run;

data _null_ ;                                                                                        
  length SYSloadedPackages $ 32767;                                                                   
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                     
    do;                                                                                               
      do until(EOF);                                                                                  
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;              
        substr(SYSloadedPackages, 1+offset, 200) = value;                                             
      end;                                                                                            
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");              
      if INDEX(lowcase(SYSloadedPackages),'#pharma_graph_gallery(0.1.0)#')>0 then 
         do;                                                                                          
          SYSloadedPackages = tranwrd(SYSloadedPackages, '#Pharma_Graph_Gallery(0.1.0)#', '##');  
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                         
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                  
          put "NOTE: " SYSloadedPackages = ;                                                          
         end ;                                                                                        
    end;                                                                                              
  stop;                                                                                               
run;                                                                                                  

%put NOTE: Unloading package Pharma_Graph_Gallery, version 0.1.0, license MIT;
%put NOTE- *** END ***;
%put NOTE- ;

/* unload.sas end */
