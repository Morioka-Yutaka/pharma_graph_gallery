filename P81B2EC0 list;

 %put NOTE- ;
 %put NOTE: Preview of the Pharma_Graph_Gallery package, version 0.1.0, license MIT;
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-26T07:30:41; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- *** START ***;

%let ls_tmp     = %sysfunc(getoption(ls));         
%let ps_tmp     = %sysfunc(getoption(ps));         
%let notes_tmp  = %sysfunc(getoption(notes));      
%let source_tmp = %sysfunc(getoption(source));     
options ls = MAX ps = MAX nonotes nosource;        
%include P81B2EC0(packagemetadata.sas) / nosource2; 

data _null_;                                                 
  if strip(symget("helpKeyword")) = " " then                 
    do until (EOF);                                          
      infile P81B2EC0(description.sas) end = EOF;  
      input;                                                 
      put _infile_;                                          
    end;                                                     
  else stop;                                                 
run;                                                         

data WORK._%sysfunc(datetime(), hex16.)_;                      
infile cards4 dlm = "/";                                       
input @;                                                       
if 0 then output;                                              
length helpKeyword $ 64;                                       
retain helpKeyword "*";                                        
drop helpKeyword;                                              
if _N_ = 1 then helpKeyword = strip(symget("helpKeyword"));    
if FIND(_INFILE_, helpKeyword, "it") or helpKeyword = "*" then 
 do;                                                           
   input (folder order type file fileshort) (: $ 256.);        
   output;                                                     
 end;                                                          
cards4;                                                        
06_macro/06/macro/pharma_graph_gallery.sas/pharma_graph_gallery/'%pharma_graph_gallery()'
06_macro/06/macro/sg001.sas/sg001/'%sg001()'
06_macro/06/macro/sg002.sas/sg002/'%sg002()'
06_macro/06/macro/sg003.sas/sg003/'%sg003()'
06_macro/06/macro/sg004.sas/sg004/'%sg004()'
06_macro/06/macro/sg005.sas/sg005/'%sg005()'
06_macro/06/macro/sg006.sas/sg006/'%sg006()'
06_macro/06/macro/sg007.sas/sg007/'%sg007()'
06_macro/06/macro/sg008.sas/sg008/'%sg008()'
06_macro/06/macro/sg009.sas/sg009/'%sg009()'
06_macro/06/macro/sg010.sas/sg010/'%sg010()'
06_macro/06/macro/sg011.sas/sg011/'%sg011()'
06_macro/06/macro/sg012.sas/sg012/'%sg012()'
06_macro/06/macro/sg013.sas/sg013/'%sg013()'
06_macro/06/macro/sg014.sas/sg014/'%sg014()'
06_macro/06/macro/sg015.sas/sg015/'%sg015()'
06_macro/06/macro/sg016.sas/sg016/'%sg016()'
06_macro/06/macro/sg017.sas/sg017/'%sg017()'
06_macro/06/macro/sg018.sas/sg018/'%sg018()'
06_macro/06/macro/sg019.sas/sg019/'%sg019()'
06_macro/06/macro/sg020.sas/sg020/'%sg020()'
06_macro/06/macro/sg022.sas/sg022/'%sg022()'
06_macro/06/macro/sg023.sas/sg023/'%sg023()'
06_macro/06/macro/sg024.sas/sg024/'%sg024()'
06_macro/06/macro/sg025.sas/sg025/'%sg025()'
06_macro/06/macro/sg026.sas/sg026/'%sg026()'
06_macro/06/macro/sg027.sas/sg027/'%sg027()'
06_macro/06/macro/sg028.sas/sg028/'%sg028()'
06_macro/06/macro/sg029.sas/sg029/'%sg029()'
06_macro/06/macro/sg030.sas/sg030/'%sg030()'
06_macro/06/macro/sg033.sas/sg033/'%sg033()'
06_macro/06/macro/sg034.sas/sg034/'%sg034()'
06_macro/06/macro/sg035.sas/sg035/'%sg035()'
06_macro/06/macro/sg036.sas/sg036/'%sg036()'
06_macro/06/macro/sg037.sas/sg037/'%sg037()'
06_macro/06/macro/sg038.sas/sg038/'%sg038()'
06_macro/06/macro/sg039.sas/sg039/'%sg039()'
06_macro/06/macro/sg040.sas/sg040/'%sg040()'
06_macro/06/macro/z_dummy_swimmer.sas/z_dummy_swimmer/'%z_dummy_swimmer()'
;;;;
run;

data _null_;                                                                        
if upcase(strip(symget("helpKeyword"))) in (" " "LICENSE") then do; stop; end;      
if NOBS = 0 then do; 
put; put ' *> No preview. Try %previewPackage(packageName,*) to display all.'; put; stop; 
end; 
  do until(EOFDS);                                                                  
   set WORK._last_ end = EOFDS nobs = NOBS;                                         
   length memberX $ 1024;                                                           
   memberX = cats("_",folder,".",file);                                             
   call execute("data _null_;                                                    ");
   call execute('infile P81B2EC0(' || strip(memberX) || ') end = EOF;  ');
   call execute("    do until(EOF);                                              ");
   call execute("      input;                                                    ");
   call execute("      put _infile_;                                             ");
   call execute("    end;                                                        ");
   call execute("  put "" "" / "" "";                                            ");
   call execute("  stop;                                                         ");
   call execute("run;                                                            ");
  end; 
  stop; 
run; 
proc delete data = WORK._last_; 
run; 
options ls = &ls_tmp. ps = &ps_tmp. &notes_tmp. &source_tmp.; 

%put NOTE: Preview of the Pharma_Graph_Gallery package, version 0.1.0, license MIT;
%put NOTE- *** END ***;

/* preview.sas end */
