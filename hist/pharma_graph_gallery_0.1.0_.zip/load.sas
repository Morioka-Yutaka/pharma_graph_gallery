filename P81B2EC0 list;

 %put NOTE- ;
 %put NOTE: Loading package Pharma_Graph_Gallery, version 0.1.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-26T07:30:41; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Run %nrstr(%%)helpPackage(Pharma_Graph_Gallery) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_; 
 if NOT ("*"=symget("cherryPick")) then do; 
  put "NOTE- "; 
  put "NOTE: *** Cherry Picking ***"; 
  put "NOTE- Cherry Picking in action!! Be advised that"; 
  put "NOTE- dependencies/required packages will not be loaded!"; 
  put "NOTE- "; 
 end; 
run; 
%include  P81B2EC0(packagemetadata.sas) / nosource2; 

 data _null_;                                                     
  call symputX("packageRequiredErrors", 0, "L");                  
 run;                                                             
 %put NOTE- *Testing required SAS components*%sysfunc(DoSubL(     
 options nonotes nosource %str(;)                                 
 options ls=max ps=max locale=en_US %str(;)                       
 /* temporary redirect log */                                     
 filename _stinit_ TEMP %str(;)                                   
 proc printto log = _stinit_ %str(;) run %str(;)                  
 /* print out setinit */                                          
 proc setinit %str(;) run %str(;)                                 
 proc printto %str(;) run %str(;)                                 
 data _null_ %str(;)                                              
   /* loadup checklist of required SAS components */              
   if _n_ = 1 then                                                
     do %str(;)                                                   
       length req $ 256 %str(;)                                   
       declare hash R() %str(;)                                   
       _N_ = R.defineKey("req") %str(;)                           
       _N_ = R.defineDone() %str(;)                               
       declare hiter iR("R") %str(;)                              
         do req = %bquote(
"BASE SAS SOFTWARE"
) %str(;)        
          _N_ = R.add(key:req,data:req) %str(;)   
         end %str(;)                                              
     end %str(;)                                                  
                                                                  
   /* read in output from proc setinit */                         
   infile _stinit_ end=eof %str(;)                                
   input %str(;)                                                  
                                                                  
   /* if component is in setinit remove it from checklist */      
   if _infile_ =: "---" then                                      
     do %str(;)                                                   
       req = upcase(substr(_infile_, 4, 64)) %str(;)              
       if R.find(key:req) = 0 then                                
         do %str(;)                                               
           _N_ = R.remove() %str(;)                               
         end %str(;)                                              
     end %str(;)                                                  
                                                                  
   /* if checklist is not null rise error */                      
   if eof and R.num_items > 0 then                                
     do %str(;)                                                   
       put "WARNING- ###########################################" %str(;) 
       put "WARNING:  The following SAS components are missing! " %str(;) 
       call symputX("packageRequiredErrors", 0, "L") %str(;)              
       do while(iR.next() = 0) %str(;)                                    
         put "WARNING-   " req %str(;)                                    
       end %str(;)                                                        
       put "WARNING:  The package may NOT WORK as expected      " %str(;) 
       put "WARNING:  or even result with ERRORS!               " %str(;) 
       put "WARNING- ###########################################" %str(;) 
       put %str(;)                                                
     end %str(;)                                                  
 run %str(;)                                                      
 filename _stinit_ clear %str(;)                                  
 options notes source %str(;)                                     
 ))*;                                                             
 data _null_;                                                     
  if 1 = symgetn("packageRequiredErrors") then                    
    do;                                                           
      put "ERROR: Loading package &packageName. will be aborted!";
      put "ERROR- Required components are missing.";              
      put "ERROR- *** STOP ***";                                  
      call symputX("packageRequiredErrors",
     'options ls = &ls_tmp. ps = &ps_tmp. 
       &notes_tmp. &source_tmp. msglevel=&msglevel_tmp. 
       &stimer_tmp. &fullstimer_tmp. ;
       data _null_;abort;run;', "L");              
    end;                                            
  else                                              
    call symputX("packageRequiredErrors", " ", "L");
 run;                                               
 &packageRequiredErrors.                            
 
%if (%str(*)=%superq(cherryPick)) or (pharma_graph_gallery in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "pharma_graph_gallery.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(pharma_graph_gallery)=1, NOTE# Macro pharma_graph_gallery exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.pharma_graph_gallery.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg001 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg001.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg001)=1, NOTE# Macro sg001 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg001.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg002 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg002.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg002)=1, NOTE# Macro sg002 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg002.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg003 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg003.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg003)=1, NOTE# Macro sg003 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg003.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg004 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg004.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg004)=1, NOTE# Macro sg004 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg004.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg005 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg005.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg005)=1, NOTE# Macro sg005 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg005.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg006 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg006.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg006)=1, NOTE# Macro sg006 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg006.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg007 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg007.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg007)=1, NOTE# Macro sg007 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg007.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg008 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg008.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg008)=1, NOTE# Macro sg008 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg008.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg009 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg009.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg009)=1, NOTE# Macro sg009 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg009.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg010 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg010.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg010)=1, NOTE# Macro sg010 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg010.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg011 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg011.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg011)=1, NOTE# Macro sg011 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg011.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg012 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg012.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg012)=1, NOTE# Macro sg012 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg012.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg013 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg013.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg013)=1, NOTE# Macro sg013 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg013.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg014 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg014.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg014)=1, NOTE# Macro sg014 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg014.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg015 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg015.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg015)=1, NOTE# Macro sg015 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg015.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg016 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg016.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg016)=1, NOTE# Macro sg016 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg016.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg017 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg017.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg017)=1, NOTE# Macro sg017 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg017.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg018 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg018.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg018)=1, NOTE# Macro sg018 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg018.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg019 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg019.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg019)=1, NOTE# Macro sg019 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg019.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg020 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg020.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg020)=1, NOTE# Macro sg020 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg020.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg022 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg022.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg022)=1, NOTE# Macro sg022 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg022.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg023 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg023.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg023)=1, NOTE# Macro sg023 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg023.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg024 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg024.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg024)=1, NOTE# Macro sg024 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg024.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg025 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg025.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg025)=1, NOTE# Macro sg025 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg025.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg026 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg026.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg026)=1, NOTE# Macro sg026 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg026.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg027 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg027.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg027)=1, NOTE# Macro sg027 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg027.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg028 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg028.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg028)=1, NOTE# Macro sg028 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg028.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg029 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg029.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg029)=1, NOTE# Macro sg029 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg029.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg030 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg030.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg030)=1, NOTE# Macro sg030 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg030.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg033 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg033.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg033)=1, NOTE# Macro sg033 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg033.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg034 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg034.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg034)=1, NOTE# Macro sg034 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg034.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg035 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg035.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg035)=1, NOTE# Macro sg035 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg035.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg036 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg036.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg036)=1, NOTE# Macro sg036 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg036.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg037 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg037.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg037)=1, NOTE# Macro sg037 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg037.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg038 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg038.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg038)=1, NOTE# Macro sg038 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg038.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg039 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg039.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg039)=1, NOTE# Macro sg039 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg039.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (sg040 in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "sg040.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(sg040)=1, NOTE# Macro sg040 exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.sg040.sas) / nosource2;
%end; 

 
%if (%str(*)=%superq(cherryPick)) or (z_dummy_swimmer in %superq(cherryPick)) %then %do; 
  %put NOTE- ;
  %put NOTE: >> Element of type macro from the file "z_dummy_swimmer.sas" will be included <<;
  %put %sysfunc(ifc(%SYSMACEXIST(z_dummy_swimmer)=1, NOTE# Macro z_dummy_swimmer exist. It will be overwritten by the macro from the Pharma_Graph_Gallery package, ));
  %include P81B2EC0(_06_macro.z_dummy_swimmer.sas) / nosource2;
%end; 

data _null_;                                   
  call symputX("cherryPick_CASLUDF",  0, "L"); 
run;                                           
data _null_;
length CASLUDF $ 32767;
dtCASLudf = datetime();
CASLUDF =                                      
    '%macro Pharma_Graph_GalleryCASLudf('         
 !! "list=1,depList="                          
 !! ')/ des = ''CASL User Defined Functions loader for Pharma_Graph_Gallery package'';'
 !! '  %if HELP = %superq(list) %then                               '
 !! '    %do;                                                       '
 !! '      %put ****************************************************************************;'
 !! '      %put This is help for the `Pharma_Graph_GalleryCASLudf` macro;'
 !! '      %put Parameters (optional) are the following:;'
 !! '      %put - `list` indicates if the list of loaded CASL UDFs should be displayed,;'
 !! '      %put %str(  )when set to the value of `1` (the default) runs `FUNCTIONLIST USER%str(;)`,;'
 !! '      %put %str(  )when set to the value of `HELP` (upcase letters!) displays this help message.;'
 !! '      %put - `depList` [technical] contains the list of dependencies required by the package.;'
 !! '      %put %str(  )for _this_ instance of the macro the default value is: `.;'
 !! '      %put The macro generated: ' !! put(dtCASLudf, E8601DT19.-L) !! ";"
 !! '      %put with the SAS Packages Framework version 20250729.;'
 !! '      %put ****************************************************************************;'
 !! '    %GOTO theEndOfTheMacro;'
 !! '    %end;'
 !! '  %if %superq(depList) ne %then                                '
 !! '    %do;                                                       '
 !! '      %do i = 1 %to %sysfunc(countw(&depList.,%str( )));       '
 !! '        %let depListNm = %scan(&depList.,&i.,%str( ));         '
 !! '        %if %SYSMACEXIST(&depListNm.CASLudf) %then             '
 !! '          %do;                                                 '
 !! '            %&depListNm.CASLudf(list=0)                        '
 !! '          %end;                                                '
 !! '      %end;                                                    '
 !! '    %end;                                                      '
 !! '  %local tmp_NOTES;'                                                                     
 !! '  %let tmp_NOTES = %sysfunc(getoption(NOTES));'                                          
 !! "  filename P81B2EC0 &ZIP. '&path./pharma_graph_gallery.&zip.';"
 !! "  options nonotes;"                      
 !! '  filename P81B2EC0 clear;'    
 !! '  options &tmp_NOTES.;'                
 !! '   %if 1 = %superq(list) %then '       
 !! '     %do; '                            
 !! "       FUNCTIONLIST USER;"               
 !! "       run;"                             
 !! '     %end; '                           
 !! '%theEndOfTheMacro: %mend;';            
run;

data _null_;
run;
data _null_;
run;
options noNotes;
%if (%str(*)=%superq(cherryPick)) %then %do; 
 data _null_ ;                                                                                              
  length SYSloadedPackages stringPCKG $ 32767;                                                              
  if SYMEXIST("SYSloadedPackages") = 1 and SYMGLOBL("SYSloadedPackages") = 1 then                           
    do;                                                                                                     
      do until(EOF);                                                                                        
        set sashelp.vmacro(where=(scope="GLOBAL" and name="SYSLOADEDPACKAGES")) end=EOF;                    
        substr(SYSloadedPackages, 1+offset, 200) = value;                                                   
      end;                                                                                                  
      SYSloadedPackages = cats("#", translate(strip(SYSloadedPackages), "#", " "), "#");                    
      indexPCKG = INDEX(lowcase(SYSloadedPackages), '#pharma_graph_gallery(');                  
      if indexPCKG = 0 then                                                                                 
         do;                                                                                                
          SYSloadedPackages = catx('#', SYSloadedPackages, 'Pharma_Graph_Gallery(0.1.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO:[SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
      else                                                                                                  
         do;                                                                                                
          stringPCKG = kscanx(substr(SYSloadedPackages, indexPCKG+1), 1, '#');                              
          SYSloadedPackages = compbl(tranwrd(SYSloadedPackages, strip(stringPCKG), "#"));                   
          SYSloadedPackages = catx('#', SYSloadedPackages, 'Pharma_Graph_Gallery(0.1.0)');              
          SYSloadedPackages = compbl(translate(SYSloadedPackages, " ", "#"));                               
          call symputX("SYSloadedPackages", SYSloadedPackages, "G");                                        
          put / "INFO:[SYSLOADEDPACKAGES] " SYSloadedPackages ;                                             
         end ;                                                                                              
    end;                                                                                                    
  else                                                                                                      
    do;                                                                                                     
      call symputX('SYSloadedPackages', 'Pharma_Graph_Gallery(0.1.0)', 'G');                            
      put / 'INFO:[SYSLOADEDPACKAGES] Pharma_Graph_Gallery(0.1.0)';                                      
    end;                                                                                                    
  stop;                                                                                                     
 run;                                                                                                       
%end; 

options NOTES;
%put NOTE- ;
%put NOTE: Loading package Pharma_Graph_Gallery, version 0.1.0, license MIT;
%put NOTE- *** END ***;

options &temp_noNotes_etc.;
%symdel temp_noNotes_etc / noWarn;
/* load.sas end */

