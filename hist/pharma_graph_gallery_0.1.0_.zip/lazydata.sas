filename P81B2EC0 list;

 %put NOTE- ;
 %put NOTE: Data for package Pharma_Graph_Gallery, version 0.1.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-05-26T07:30:41; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(Pharma_Graph_Gallery) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package Pharma_Graph_Gallery, version 0.1.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

